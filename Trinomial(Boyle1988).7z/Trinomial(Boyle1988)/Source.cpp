#include <math.h>
#include <cstdio>
#include <cstdlib>
#include <malloc.h>

#define max(a,b) (a>b?a:b)
#define min(a,b) (a>b?b:a)

double Call_Boyle1988_European(double S, double K, double R, double Sigma, double T, int N, double Lambda)
{
	double dt, result;
	double pu, ph, pd;		//Probability of up-jump,Probability of horizontal,Probability of down-jump
	double u;				//Jump amplitudes
	double *S_tree, *Call_tree;
	int i, j;
	double M, V;

	dt = T / N;
	M = exp(R*dt);
	V = pow(M, 2)*(exp(pow(Sigma, 2)*dt) - 1);

	if (Lambda)
		if (Lambda <= 2 && Lambda > 1.1)
			u = exp(Lambda*Sigma*sqrt(dt));
		else
			u = exp(1.1*Sigma*sqrt(dt));
	else
		u = exp(1.1*Sigma*sqrt(dt));

	pu = ((V + pow(M, 2) - M)*u - (M - 1)) / ((u - 1)*(pow(u, 2) - 1));
	pd = ((V + pow(M, 2) - M)*pow(u, 2) - (M - 1)*pow(u, 3)) / ((u - 1)*(pow(u, 2) - 1));
	ph = 1 - pu - pd;

	//==========================
	//open memory for S_tree
	S_tree = new double[2 * N + 1];
	//open memory for Put_tree
	Call_tree = new double[2 * N + 1];
	//==========================

	for (j = 0; j < 2 * N + 1; j++)
	{
		S_tree[j] = S * pow(u, j - N);
		Call_tree[j] = max(0, S_tree[j] - K);
	}

	for (i = 1; i <= N; i++)
		for (j = 0; j < 2 * (N - i) + 1; j++)
			Call_tree[j] = exp(-R * dt)*(pu*Call_tree[j + 2] + ph * Call_tree[j + 1] + pd * Call_tree[j]);

	result = Call_tree[0];

	delete[] S_tree;
	delete[] Call_tree;

	return result;
}

int main() {
	double ans;

	ans = Call_Boyle1988_European(100.0, 110.0, 0.05, 0.3, 1, 100, 0);
	return 0;
}