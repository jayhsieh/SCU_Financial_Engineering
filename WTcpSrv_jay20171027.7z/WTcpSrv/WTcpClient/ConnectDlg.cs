using System;
using System.Windows.Forms;

namespace WTcpClient {
    /// <summary>
    /// Summary description for ConnectDlg.
    /// </summary>
    public class ConnectDlg : Form {
        private Button OkBtn;
        private Button CancelBtn;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox UName;
        private TextBox PWord;
        private TextBox IPAdd;
        private TextBox Port;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private string username;
        private string password;
        private string ipAdd;
        private string port;

        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public string UserName {
            get {
                return username;
            }
            set {
                username = value;
                UName.Text = username;
            }
        }
        /// <summary>
        /// Gets or sets the pass word.
        /// </summary>
        /// <value>
        /// The pass word.
        /// </value>
        public string PassWord {
            get {
                return password;
            }
            set {
                password = value;
                PWord.Text = password;
            }
        }
        /// <summary>
        /// Gets or sets the port number.
        /// </summary>
        /// <value>
        /// The port number.
        /// </value>
        public string PortNum {
            get {
                return port;
            }
            set {
                port = value;
                Port.Text = port;
            }
        }
        /// <summary>
        /// Gets or sets the ip add.
        /// </summary>
        /// <value>
        /// The ip add.
        /// </value>
        public string IpAdd {
            get {
                return ipAdd;
            }
            set {
                ipAdd = value;
                IPAdd.Text = ipAdd;
            }
        }

        private System.ComponentModel.Container components = null;

        public ConnectDlg() {
            // Required for Windows Form Designer support
            InitializeComponent();

            // TODO: Add any constructor code after InitializeComponent call
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing) {
            if (disposing) {
                if (components != null) {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent() {      
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();
            this.OkBtn = new Button();
            this.CancelBtn = new Button();
            this.IPAdd = new TextBox();
            this.Port = new TextBox();
            this.UName = new TextBox();
            this.PWord = new TextBox();
            this.SuspendLayout();

            // ConnectDlg
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 15);
            this.ClientSize = new System.Drawing.Size(292, 210);
            this.Controls.Add(this.Port);
            this.Controls.Add(this.IPAdd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.UName);
            this.Controls.Add(this.PWord);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.OkBtn);
            this.Name = "ConnectDlg";
            this.Text = "ConnectDlg";
            this.ResumeLayout(false);
            this.PerformLayout();

            //================================================================= 
            // label1
            this.label1.Location = new System.Drawing.Point(40, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "IP Address";
            // label2
            this.label2.Location = new System.Drawing.Point(40, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 28);
            this.label2.TabIndex = 4;
            this.label2.Text = "Port";
            // label3
            this.label3.Location = new System.Drawing.Point(40, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "User Name";
            // label4
            this.label4.Location = new System.Drawing.Point(40, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 28);
            this.label4.TabIndex = 4;
            this.label4.Text = "Password";

            //================================================================= 
            // OkBtn
            this.OkBtn.DialogResult = DialogResult.OK;
            this.OkBtn.Location = new System.Drawing.Point(48, 166);
            this.OkBtn.Name = "OkBtn";
            this.OkBtn.Size = new System.Drawing.Size(75, 27);
            this.OkBtn.TabIndex = 7;
            this.OkBtn.Text = "Ok";
            this.OkBtn.Click += new EventHandler(this.OnOk);
            // CancelBtn
            this.CancelBtn.DialogResult = DialogResult.Cancel;
            this.CancelBtn.Location = new System.Drawing.Point(184, 166);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 27);
            this.CancelBtn.TabIndex = 6;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.Click += new EventHandler(this.OnCancel);

            //================================================================= 
            // IPAdd
            this.IPAdd.Location = new System.Drawing.Point(120, 18);
            this.IPAdd.Name = "IPAdd";
            this.IPAdd.Size = new System.Drawing.Size(104, 22);
            this.IPAdd.TabIndex = 10;
            this.IPAdd.Text = "127.0.0.1";
            // Port
            this.Port.Location = new System.Drawing.Point(120, 55);
            this.Port.Name = "Port";
            this.Port.Size = new System.Drawing.Size(104, 22);
            this.Port.TabIndex = 11;
            this.Port.Text = "8002";
            // UName
            this.UName.Location = new System.Drawing.Point(120, 92);
            this.UName.Name = "UName";
            this.UName.Size = new System.Drawing.Size(104, 22);
            this.UName.TabIndex = 3;
            this.UName.Text = "user1";
            // PWord
            this.PWord.Location = new System.Drawing.Point(120, 129);
            this.PWord.Name = "PWord";
            this.PWord.PasswordChar = '*';
            this.PWord.Size = new System.Drawing.Size(104, 22);
            this.PWord.TabIndex = 5;
            this.PWord.Text = "user1";
        }
        #endregion

        protected void OnCancel(Object mySender, EventArgs myArgs) {
            Close();
        }

        protected void OnOk(Object mySender, EventArgs myArgs) {
            UserName = UName.Text;
            PassWord = PWord.Text;
            ipAdd = IPAdd.Text;
            port = Port.Text;
        }
    }
}
