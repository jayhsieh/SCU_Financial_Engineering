using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Text;
using System.Xml;
using System.IO;

namespace WTcpClient {
    /// <summary>
    /// ���W��
    /// </summary>
    public struct FieldName {
        public string symbol;
        public string bid;
        public string offer;
        public string volume;
    }
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class Form1 : Form {
        private Encoding ASCII = Encoding.ASCII;
        private Thread t;
        private Socket s;
        FieldName fn = new FieldName();
        static AutoResetEvent JobDone = new AutoResetEvent(false);
        MethodInvoker miv;

        private MainMenu mainMenu1;
        private StatusBar sbar;
        private ListView listView1;

        private MenuItem layer1_File;
        private MenuItem layer2_Exit;
        private MenuItem layer1_Connect;
        private MenuItem layer1_DisConnect;

        private ColumnHeader title_Symbol;
        private ColumnHeader title_Bid;
        private ColumnHeader title_Offer;
        private ColumnHeader title_Volume;

        private IContainer components;
        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1() {
            InitializeComponent();
            // TODO: Add any constructor code after InitializeComponent call
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing) {
            if (disposing)
                if (components != null)
                    components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent() {
            components = new Container();
            mainMenu1 = new MainMenu(components);
            layer1_File = new MenuItem();
            layer2_Exit = new MenuItem();
            layer1_Connect = new MenuItem();
            layer1_DisConnect = new MenuItem();
            title_Offer = new ColumnHeader();
            title_Symbol = new ColumnHeader();
            title_Bid = new ColumnHeader();
            sbar = new StatusBar();
            title_Volume = new ColumnHeader();
            listView1 = new ListView();
            SuspendLayout();

            //================================================================= 
            // Form1
            AutoScaleBaseSize = new Size(5, 15);
            ClientSize = new Size(296, 225);
            Controls.Add(sbar);
            Controls.Add(listView1);
            Menu = mainMenu1;
            Name = "Form1";
            Text = "TcpClient";
            ResumeLayout(false);

            //================================================================= 
            // mainMenu1
            mainMenu1.MenuItems.AddRange(new MenuItem[] { layer1_File, layer1_Connect, layer1_DisConnect });

            // listView1
            listView1.BackColor = Color.WhiteSmoke;
            listView1.Columns.AddRange(new ColumnHeader[] { title_Symbol, title_Bid, title_Offer, title_Volume });
            listView1.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            listView1.FullRowSelect = true;
            listView1.Location = new Point(8, 9);
            listView1.Name = "listView1";
            listView1.Size = new Size(280, 222);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;

            //================================================================= 
            // sbar
            sbar.Location = new Point(0, 202);
            sbar.Name = "sbar";
            sbar.Size = new Size(296, 23);
            sbar.TabIndex = 1;
            sbar.Text = "Click Connect";

            //================================================================= 
            // File
            layer1_File.Index = 0;
            layer1_File.MenuItems.AddRange(new MenuItem[] { layer2_Exit });
            layer1_File.Text = "File";
            // Exit
            layer2_Exit.Index = 0;
            layer2_Exit.Text = "Exit";
            layer2_Exit.Click += new EventHandler(MenuExit_Click);

            //================================================================= 
            // Connect
            layer1_Connect.Index = 1;
            layer1_Connect.Text = "Connect";
            layer1_Connect.Click += new EventHandler(menuConnect_Click);

            //================================================================= 
            // DisConnect
            layer1_DisConnect.Index = 2;
            layer1_DisConnect.Text = "DisConnect";
            layer1_DisConnect.Click += new EventHandler(MenuDisConnect_Click);

            //================================================================= 
            // UserName
            title_Symbol.Text = "Symbol";
            title_Symbol.Width = 54;
            // Bid
            title_Bid.Text = "Bid";
            title_Bid.TextAlign = HorizontalAlignment.Center;
            title_Bid.Width = 66;
            // Offer
            title_Offer.Text = "Offer";
            title_Offer.TextAlign = HorizontalAlignment.Center;
            title_Offer.Width = 69;
            // Volume
            title_Volume.Text = "Volume";
            title_Volume.TextAlign = HorizontalAlignment.Center;
            title_Volume.Width = 86;
        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            Application.Run(new Form1());
        }

        private void menuConnect_Click(object sender, EventArgs e) {
            var myDlg = new ConnectDlg();
            myDlg.ShowDialog(this);

            if (myDlg.DialogResult == DialogResult.OK) {
                s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                var hostadd = IPAddress.Parse(myDlg.IpAdd);
                var port = int.Parse(myDlg.PortNum);
                var EPhost = new IPEndPoint(hostadd, port);

                try {
                    s.Connect(EPhost);

                    if (s.Connected) {
                        Byte[] bBuf;
                        string buf;
                        buf = String.Format("{0}:{1}", myDlg.UserName, myDlg.PassWord);
                        bBuf = ASCII.GetBytes(buf);
                        s.Send(bBuf, 0, bBuf.Length, 0);
                        t = new Thread(new ThreadStart(StartRecieve));
                        t.Start();
                        sbar.Text = "Ready to recieve data";
                        layer1_Connect.Enabled = false;
                    }
                } catch (Exception e1) {
                    MessageBox.Show(e1.ToString());
                }
            }
        }

        private void StartRecieve() {
            miv = new MethodInvoker(UpdateListView);
            int cnt = 0;
            string tmp = null;
            var firstb = new Byte[1];

            while (true) {
                try {
                    var receive = new Byte[1];
                    var ret = s.Receive(receive, 1, 0);

                    if (ret > 0) {
                        switch (receive[0]) {
                            case 11: //check start message
                                cnt = 0;
                                break;
                            case 10: // check end message
                                cnt = 0;
                                if (firstb[0] == ':')
                                    HandleCommand(tmp);
                                else if (firstb[0] == '<')
                                    HandleXml(tmp);
                                else
                                    HandleText(tmp);
                                tmp = null;
                                break;
                            default:
                                if (cnt == 0)
                                    firstb[0] = receive[0];
                                tmp += Encoding.ASCII.GetString(receive);
                                cnt++;
                                break;
                        }
                    }
                } catch (Exception e) {
                    Console.WriteLine(e.Message);
                    if (!s.Connected) {
                        layer1_Connect.Enabled = true;
                        break;
                    }
                }
            }
            t.Abort();
        }

        private void HandleCommand(string str) {
            layer1_Connect.Enabled = true;
            sbar.Text = Mid(str, 1, str.Length - 1);
        }

        private void HandleXml(string str) {
            int textCount = 0;
            var stream = new StringReader(str);
            var tr = new XmlTextReader(stream);

            while (tr.Read()) {
                switch (tr.NodeType) {
                    case XmlNodeType.Element:
                        //tmp2 = tr.Name;
                        break;
                    case XmlNodeType.Text:
                        switch (++textCount) {
                            case 1:
                                fn.symbol = tr.Value;
                                break;
                            case 2:
                                fn.bid = tr.Value;
                                break;
                            case 3:
                                fn.offer = tr.Value;
                                break;
                            case 4:
                                fn.volume = tr.Value;
                                break;
                        }
                        break;
                }
            }

            BeginInvoke(miv);
            JobDone.WaitOne();
        }

        private void HandleText(string str) {
            fn.symbol = Mid(str, 0, 4).TrimEnd(' ');
            fn.bid = Mid(str, 4, 5).TrimEnd(' ');
            fn.offer = Mid(str, 9, 5).TrimEnd(' ');
            fn.volume = Mid(str, 16, str.Length - 16).TrimEnd(' ');
            BeginInvoke(miv);
            Thread.Sleep(300);
            JobDone.WaitOne();
        }

        private string CreateXmlElement(string elem, int ord) {
            string tmp = null;
            if (ord == 1)
                tmp = String.Format("<{0}>", elem);
            else
                tmp = String.Format("</{0}>", elem);

            return tmp;
        }

        public string Mid(String strParam, int startIndex, int length) {
            string tmpstr = strParam.Substring(startIndex, length);
            return tmpstr;
        }

        private void UpdateListView() {
            int ind = -1;

            for (var i = 0; i < listView1.Items.Count; i++) {
                if (listView1.Items[i].Text == fn.symbol.ToString())
                    ind = i;
                if (ind > -1) {
                    break;
                }
            }

            if (ind == -1) {
                var newItem = new ListViewItem(fn.symbol.ToString());
                newItem.SubItems.Add(fn.bid);
                newItem.SubItems.Add(fn.offer);
                newItem.SubItems.Add(fn.volume);

                listView1.Items.Add(newItem);
                var i = listView1.Items.IndexOf(newItem);
                SetRowColor(i, Color.FromArgb(255, 255, 175));
                SetColColorHL(i, 0, Color.FromArgb(128, 0, 0));
                SetColColorHL(i, 1, Color.FromArgb(128, 0, 0));
                listView1.Update();
                Thread.Sleep(300);
                SetColColor(i, 0, Color.FromArgb(255, 255, 175));
                SetColColor(i, 1, Color.FromArgb(255, 255, 175));
            } else {
                listView1.Items[ind].Text = fn.symbol.ToString();
                listView1.Items[ind].SubItems[1].Text = (fn.bid);
                listView1.Items[ind].SubItems[2].Text = (fn.offer);
                listView1.Items[ind].SubItems[3].Text = (fn.volume);
                SetColColorHL(ind, 0, Color.FromArgb(128, 0, 0));
                SetColColorHL(ind, 1, Color.FromArgb(128, 0, 0));
                listView1.Update();
                Thread.Sleep(300);
                SetColColor(ind, 0, Color.FromArgb(255, 255, 175));
                SetColColor(ind, 1, Color.FromArgb(255, 255, 175));
            }
            JobDone.Set();
        }

        private void SetRowColor(int rowNum, Color colr) {
            for (var i = 0; i < listView1.Items[rowNum].SubItems.Count; i++)
                if (rowNum % 2 != 0)
                    listView1.Items[rowNum].SubItems[i].BackColor = colr;
        }

        private void SetColColor(int rowNum, int colNum, Color colr) {
            if (rowNum % 2 != 0)
                listView1.Items[rowNum].SubItems[colNum].BackColor = colr;
            else
                listView1.Items[rowNum].SubItems[colNum].BackColor = Color.FromArgb(248, 248, 248);
            if (colNum == 0) {
                listView1.Items[rowNum].SubItems[colNum].ForeColor = Color.FromArgb(128, 0, 64);
                listView1.Items[rowNum].SubItems[colNum].BackColor = Color.FromArgb(197, 197, 182);
            } else
                listView1.Items[rowNum].SubItems[colNum].ForeColor = Color.FromArgb(20, 20, 20);
        }

        private void SetColColorHL(int rowNum, int colNum, Color colr) {
            listView1.Items[rowNum].SubItems[colNum].BackColor = colr;
            listView1.Items[rowNum].SubItems[colNum].ForeColor = Color.FromArgb(255, 255, 255);
        }

        private void MenuExit_Click(object sender, EventArgs e) {
            if (s != null)
                s.Close();
            if (t != null)
                if (t.IsAlive)
                    t.Abort();
            Application.Exit();
        }

        private void MenuDisConnect_Click(object sender, EventArgs e) {
            if (s != null)
                s.Close();
            sbar.Text = "Click Connect";
            layer1_Connect.Enabled = true;
        }
    }
}
