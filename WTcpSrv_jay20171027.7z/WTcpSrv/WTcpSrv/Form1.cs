using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using System.Xml;
using System.ComponentModel;
using System.Net;

namespace WTcpSrv {
    /// <summary>
    /// ���W��
    /// </summary>
    public struct FieldName {
        public string symbol;
        public string bid;
        public string offer;
        public string volume;
    }
    /// <summary>
    /// ��ƨӷ�: FX, Futures, Options, Equity
    /// </summary>
    public enum SourceFrom {
        TextFile = 0,
        XMLFile = 1,
        UBS_API = 2,
        HSBC_API = 3,
        FXall_API = 4,
        Others = 5
    }
    /// <summary>
    /// �����]�p
    /// </summary>
    /// <seealso cref="Form" />
    public class Form1 : Form {
        private MainMenu mainMenu1;
        private MenuItem layer1_File;
        private MenuItem layer2_Clean;
        private MenuItem layer2_Exit;
       
        private MenuItem layer1_Server;
        private MenuItem layer2_Start;
        private MenuItem layer2_Stop;

        private MenuItem layer1_LoadData;
        private MenuItem layer2_XML_file;
        private MenuItem layer2_Text_file;
        private MenuItem layer2_UBS_api;
        private MenuItem layer2_HSBC_api;
        private MenuItem layer2_FxAll_api;

        private FieldName fn = new FieldName();
        private SourceFrom fileType;

        private int MaxConnected = 400;
        private int HighLightDelay = 300;

        private Encoding ASCII = Encoding.ASCII;
        private static long connectId = 0;
        private static AutoResetEvent JobDone = new AutoResetEvent(false);

        private TcpListener tcpLsn;
        private Hashtable socketHolder = new Hashtable();
        private Hashtable threadHolder = new Hashtable();
        private Hashtable userHolder = new Hashtable();
        bool keepUser;

        private Thread fThd;

        private IContainer components;

        private ListView listView1;
        private ColumnHeader title_Bid;
        private ColumnHeader title_Symbol;
        private ColumnHeader title_Offer;
        private ColumnHeader title_Volumn;

        private ListView listView2;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ImageList imageList1;
        private StatusBar stBar;
        private StatusBarPanel stpanel;
        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1() {
            // Required for Windows Form Designer support
            InitializeComponent();
            // �إ� IPAddress ����(����)
            var localAddr = IPAddress.Parse("127.0.0.1");
            // �إߺ�ť����
            tcpLsn = new TcpListener(localAddr, 8002);
            // �Ұʺ�ť
            tcpLsn.Start();
            stpanel.Text = "Listen at: " + tcpLsn.LocalEndpoint.ToString();
            var tcpThd = new Thread(new ThreadStart(WaitingForClient));
            threadHolder.Add(connectId, tcpThd);
            tcpThd.Start();

            Paint += new PaintEventHandler(Form1_Paint);
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
            Graphics g = e.Graphics;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing) {
            if (disposing) {
                if (components != null)
                    components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent() {
            this.components = new Container();
            ComponentResourceManager resources = new ComponentResourceManager(typeof(Form1));
            this.mainMenu1 = new MainMenu(this.components);
            this.layer1_File = new MenuItem();
            this.layer2_Clean = new MenuItem();
            this.layer2_Exit = new MenuItem();
            this.layer1_Server = new MenuItem();
            this.layer2_Start = new MenuItem();
            this.layer2_Stop = new MenuItem();
            this.layer1_LoadData = new MenuItem();
            this.layer2_XML_file = new MenuItem();
            this.layer2_Text_file = new MenuItem();
            this.layer2_UBS_api = new MenuItem();
            this.layer2_HSBC_api = new MenuItem();
            this.layer2_FxAll_api = new MenuItem();
            this.imageList1 = new ImageList(this.components);
            this.stBar = new StatusBar();
            this.stpanel = new StatusBarPanel();
            this.columnHeader1 = new ColumnHeader();
            this.columnHeader2 = new ColumnHeader();
            this.columnHeader3 = new ColumnHeader();
            this.title_Symbol = new ColumnHeader();
            this.title_Bid = new ColumnHeader();
            this.title_Offer = new ColumnHeader();
            this.title_Volumn = new ColumnHeader();
            this.listView1 = new ListView();
            this.listView2 = new ListView();
            ((ISupportInitialize)(this.stpanel)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new MenuItem[] {
            this.layer1_File,
            this.layer1_Server,
            this.layer1_LoadData});
            // 
            // layer1_File
            // 
            this.layer1_File.Index = 0;
            this.layer1_File.MenuItems.AddRange(new MenuItem[] {
            this.layer2_Clean,
            this.layer2_Exit});
            this.layer1_File.Text = "File";
            // 
            // layer2_Clean
            // 
            this.layer2_Clean.Index = 0;
            this.layer2_Clean.Text = "Clean";
            this.layer2_Clean.Click += new EventHandler(this.MenuClean_Click);
            // 
            // layer2_Exit
            // 
            this.layer2_Exit.Index = 1;
            this.layer2_Exit.Text = "Exit";
            this.layer2_Exit.Click += new EventHandler(this.MenuExit_Click);
            // 
            // layer1_Server
            // 
            this.layer1_Server.Index = 1;
            this.layer1_Server.MenuItems.AddRange(new MenuItem[] {
            this.layer2_Start,
            this.layer2_Stop});
            this.layer1_Server.Text = "Server";
            // 
            // layer2_Start
            // 
            this.layer2_Start.Checked = true;
            this.layer2_Start.Index = 0;
            this.layer2_Start.Text = "Start";
            this.layer2_Start.Click += new EventHandler(this.MenuStart_Click);
            // 
            // layer2_Stop
            // 
            this.layer2_Stop.Index = 1;
            this.layer2_Stop.Text = "Stop";
            this.layer2_Stop.Click += new EventHandler(this.MemuStop_Click);
            // 
            // layer1_LoadData
            // 
            this.layer1_LoadData.Index = 2;
            this.layer1_LoadData.MenuItems.AddRange(new MenuItem[] {
            this.layer2_XML_file,
            this.layer2_Text_file,
            this.layer2_UBS_api,
            this.layer2_HSBC_api,
            this.layer2_FxAll_api});
            this.layer1_LoadData.Text = "Load Data";
            // 
            // layer2_XML_file
            // 
            this.layer2_XML_file.Index = 0;
            this.layer2_XML_file.Text = "XML File";
            this.layer2_XML_file.Click += new EventHandler(this.MenuXML_file_Click);
            // 
            // layer2_Text_file
            // 
            this.layer2_Text_file.Index = 1;
            this.layer2_Text_file.Text = "Text File";
            this.layer2_Text_file.Click += new EventHandler(this.MenuText_file_Click);
            // 
            // layer2_UBS_api
            // 
            this.layer2_UBS_api.Index = 2;
            this.layer2_UBS_api.Text = "UBS API";
            // 
            // layer2_HSBC_api
            // 
            this.layer2_HSBC_api.Index = 3;
            this.layer2_HSBC_api.Text = "HSBC API";
            // 
            // layer2_FxAll_api
            // 
            this.layer2_FxAll_api.Index = 4;
            this.layer2_FxAll_api.Text = "FxAll API";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "");
            this.imageList1.Images.SetKeyName(1, "");
            // 
            // stBar
            // 
            this.stBar.Location = new Point(0, 501);
            this.stBar.Name = "stBar";
            this.stBar.Panels.AddRange(new StatusBarPanel[] {
            this.stpanel});
            this.stBar.RightToLeft = RightToLeft.Yes;
            this.stBar.ShowPanels = true;
            this.stBar.Size = new Size(320, 23);
            this.stBar.TabIndex = 3;
            // 
            // stpanel
            // 
            this.stpanel.Alignment = HorizontalAlignment.Right;
            this.stpanel.Name = "stpanel";
            this.stpanel.Width = 200;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Status";
            this.columnHeader1.Width = 57;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "User Name";
            this.columnHeader2.Width = 86;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Login Time";
            this.columnHeader3.Width = 141;
            // 
            // title_Symbol
            // 
            this.title_Symbol.Text = "Symbol";
            // 
            // title_Bid
            // 
            this.title_Bid.Text = "Bid";
            this.title_Bid.TextAlign = HorizontalAlignment.Center;
            // 
            // title_Offer
            // 
            this.title_Offer.Text = "Offer";
            this.title_Offer.TextAlign = HorizontalAlignment.Center;
            this.title_Offer.Width = 72;
            // 
            // title_Volumn
            // 
            this.title_Volumn.Text = "Volume";
            this.title_Volumn.TextAlign = HorizontalAlignment.Center;
            this.title_Volumn.Width = 92;
            // 
            // listView1
            // 
            this.listView1.AccessibleDescription = "";
            this.listView1.AccessibleName = "";
            this.listView1.BackColor = Color.Black;
            this.listView1.Columns.AddRange(new ColumnHeader[] {
            this.title_Symbol,
            this.title_Bid,
            this.title_Offer,
            this.title_Volumn});
            this.listView1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            this.listView1.ForeColor = SystemColors.Info;
            this.listView1.HideSelection = false;
            this.listView1.HoverSelection = true;
            this.listView1.Location = new Point(16, 218);
            this.listView1.Name = "listView1";
            this.listView1.RightToLeft = RightToLeft.No;
            this.listView1.Size = new Size(288, 268);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = View.Details;
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listView2.Location = new Point(16, 9);
            this.listView2.Name = "listView2";
            this.listView2.Size = new Size(288, 189);
            this.listView2.SmallImageList = this.imageList1;
            this.listView2.StateImageList = this.imageList1;
            this.listView2.TabIndex = 2;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = View.Details;
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new Size(5, 15);
            this.ClientSize = new Size(320, 524);
            this.Controls.Add(this.stBar);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.listView1);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "E.SUN FX Server";
            ((ISupportInitialize)(this.stpanel)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            Application.Run(new Form1());
        }

        private Object thisLock = new Object();

        /// <summary>
        /// Waitings for client.
        /// </summary>
        public void WaitingForClient() {
            while (true) {
                // Accept will block until someone connects
                var socket = tcpLsn.AcceptSocket();
                if (connectId < 10000)
                    Interlocked.Increment(ref connectId);
                else
                    connectId = 1;

                if (socketHolder.Count < MaxConnected) {
                    while (socketHolder.Contains(connectId)) {
                        Interlocked.Increment(ref connectId);
                    }

                    var td = new Thread(new ThreadStart(ReadSocket));
                    lock (thisLock) {
                        // it is used to keep connected Sockets
                        socketHolder.Add(connectId, socket);
                        // it is used to keep the active thread
                        threadHolder.Add(connectId, td);
                    }
                    td.Start();
                }
            }
        }
        /// <summary>
        /// Reads the socket.
        /// </summary>
        public void ReadSocket() {
            // realId will be not changed for each thread, 
            // but connectId is changed. it can't be used to delete object from Hashtable
            long realId = connectId;
            int ind = -1;
            var s = (Socket)socketHolder[realId];

            while (true) {
                if (s.Connected) {
                    Byte[] receive = new Byte[37];
                    try {
                        // Receive will block until data coming
                        // ret is 0 or Exception happen when Socket connection is broken
                        var ret = s.Receive(receive, receive.Length, 0);
                        if (ret > 0) {
                            string tmp = Encoding.ASCII.GetString(receive);

                            if (tmp.Length > 0) {
                                var now1 = DateTime.Now;
                                var strDate = now1.ToShortDateString() + " " + now1.ToLongTimeString();
                                var newItem = new ListViewItem();

                                var strArry = tmp.Split(':');
                                var code = CheckUserInfo(strArry[0]);

                                if (code == 2) {
                                    userHolder.Add(realId, strArry[0]);
                                    newItem.SubItems.Add(strArry[0]);
                                    newItem.ImageIndex = 0;
                                    newItem.SubItems.Add(strDate);
                                    listView2.Items.Add(newItem);
                                    ind = listView2.Items.IndexOf(newItem);
                                } else if (code == 1) {
                                    var connFail = String.Format(":The user {0} is connected already", strArry[0]);
                                    var byteData = ASCII.GetBytes(connFail.ToCharArray());
                                    s.Send(byteData, byteData.Length, 0);
                                    s.Close();
                                    break;
                                } else if (code == 0) {
                                    var connFail = String.Format(":The user {0} is invalidate", strArry[0]);
                                    var byteData = ASCII.GetBytes(connFail.ToCharArray());
                                    s.Send(byteData, byteData.Length, 0);
                                    s.Close();
                                    break;
                                }
                            }
                        } else {
                            listView2.Items[ind].ImageIndex = 1;
                            keepUser = false;
                            break;
                        }
                    } catch (Exception e) {
                        Console.WriteLine(e.Message);
                        if (!s.Connected) {
                            listView2.Items[ind].ImageIndex=1;
                            keepUser = false;
                            break;
                        }
                    }
                }
            }
            CloseTheThread(realId);
        }

        private int CheckUserInfo(string userId) {
            //  check the userId and password first
            //  TODO
            if (userHolder.ContainsValue(userId)) {
                keepUser = true;
                return 1; // user is login already		
            } else {
                return 2; // user not in the database
            }
            // return 0: user login error
        }

        private void CloseTheThread(long realId) {
            if (!keepUser)
                userHolder.Remove(realId);
            var thd = (Thread)threadHolder[realId];

            lock (thisLock) {
                socketHolder.Remove(realId);
                threadHolder.Remove(realId);
            }
            thd.Abort();
        }

        private void MenuText_file_Click(object sender, EventArgs e) {
            fThd = new Thread(new ThreadStart(LoadFileThread));
            fileType = SourceFrom.TextFile;
            fThd.Start();
        }

        private void MenuXML_file_Click(object sender, EventArgs e) {
            fThd = new Thread(new ThreadStart(LoadXmlThread));
            fileType = SourceFrom.XMLFile;
            fThd.Start();
        }
        /// <summary>
        /// Loads the thread.
        /// </summary>
        public void LoadFileThread() {
            var miv = new MethodInvoker(UpdateListView);
            string tmp = null;

            switch (fileType) {
                case SourceFrom.TextFile:
                    string sendMsg = null;
                    var sr = File.OpenText("Issue.txt");

                    while ((tmp = sr.ReadLine()) != null) {
                        if (tmp == "")
                            break;

                        fn.symbol = Mid(tmp, 0, 4).TrimEnd(' ');
                        fn.bid = Mid(tmp, 4, 5).TrimEnd(' ');
                        fn.offer = Mid(tmp, 9, 5).TrimEnd(' ');
                        fn.volume = Mid(tmp, 16, tmp.Length - 16).TrimEnd(' ');

                        sendMsg = "\v" + tmp + "\n"; // add send message's head and end char
                        SendDataToAllClient(sendMsg);

                        BeginInvoke(miv);
                        JobDone.WaitOne();
                    }
                    sr.Close();
                    break;
            }
            fThd.Abort();
        }
        /// <summary>
        /// Loads the XML thread.
        /// </summary>
        public void LoadXmlThread() {
            var miv = new MethodInvoker(UpdateListView);
            string tmp = null;
            string xmlString = null;

            int recordFlg = -1;
            int textCount = 0;
            xmlString = "\v" + "<?xml version='1.0'?>";

            XmlTextReader tr = new XmlTextReader("issue.xml");
            while (tr.Read()) {
                switch (tr.NodeType) {
                    case XmlNodeType.Element:
                        if (tr.Name == "Issue") {
                            recordFlg++;
                            if (recordFlg > 0) {
                                textCount = 0;
                                xmlString += CreateXmlElement(tr.Name, 2);
                                xmlString += "\n";
                                SendDataToAllClient(xmlString);
                                xmlString = "\v" + "<?xml version='1.0'?>";

                                BeginInvoke(miv);
                                JobDone.WaitOne();
                            }
                        }

                        if (recordFlg >= 0) {
                            xmlString += CreateXmlElement(tr.Name, 1);
                            tmp = tr.Name;
                        }
                        break;

                    case XmlNodeType.Text:
                        switch (++textCount) {
                            case 1:
                                fn.symbol = tr.Value;
                                break;
                            case 2:
                                fn.bid = tr.Value;
                                break;
                            case 3:
                                fn.offer = tr.Value;
                                break;
                            case 4:
                                fn.volume = tr.Value;
                                break;
                        }
                        xmlString += tr.Value;
                        xmlString += CreateXmlElement(tmp, 2);
                        break;
                }
            }
            fThd.Abort();
        }

        private string CreateXmlElement(string elem, int ord) {
            string tmp = null;
            if (ord == 1)
                tmp = String.Format("<{0}>", elem);
            else
                tmp = String.Format("</{0}>", elem);

            return tmp;
        }

        private void SendDataToAllClient(string str) {
            foreach (Socket s in socketHolder.Values) {
                if (s.Connected) {
                    Byte[] byteData = ASCII.GetBytes(str.ToCharArray());
                    s.Send(byteData, byteData.Length, 0);
                }
            }
        }

        private void UpdateListView() {
            int ind = -1;

            for (var i = 0; i < listView1.Items.Count; i++) {
                if (listView1.Items[i].Text == fn.symbol.ToString()) {
                    ind = i;
                    break;
                }
            }

            if (ind == -1) {
                var newItem = new ListViewItem(fn.symbol.ToString());
                newItem.SubItems.Add(fn.bid);
                newItem.SubItems.Add(fn.offer);
                newItem.SubItems.Add(fn.volume);

                listView1.Items.Add(newItem);
                var i = listView1.Items.IndexOf(newItem);
                SetColColorHL(i, 0, Color.FromArgb(255, 99, 99));
                SetColColorHL(i, 1, Color.FromArgb(255, 99, 99));
                listView1.Update();
                Thread.Sleep(HighLightDelay);
                SetColColor(i, 0, Color.FromArgb(0, 255, 128));
                SetColColor(i, 1, Color.FromArgb(255, 255, 128));
            } else {
                listView1.Items[ind].Text = fn.symbol.ToString();
                listView1.Items[ind].SubItems[1].Text = (fn.bid);
                listView1.Items[ind].SubItems[2].Text = (fn.offer);
                listView1.Items[ind].SubItems[3].Text = (fn.volume);
                SetColColorHL(ind, 0, Color.FromArgb(255, 99, 99));
                SetColColorHL(ind, 1, Color.FromArgb(255, 99, 99));
                listView1.Update();
                Thread.Sleep(HighLightDelay);
                SetColColor(ind, 0, Color.FromArgb(0, 255, 128));
                SetColColor(ind, 1, Color.FromArgb(255, 255, 128));
            }
            JobDone.Set();
        }

        private void SetRowColor(int rowNum, Color colr) {
            for (var i = 0; i < listView1.Items[rowNum].SubItems.Count; i++)
                if (rowNum % 2 == 0)
                    listView1.Items[rowNum].SubItems[i].BackColor = colr;
        }

        private void SetColColor(int rowNum, int colNum, Color colr) {
            listView1.Items[rowNum].SubItems[colNum].ForeColor = colr;
        }

        private void SetColColorHL(int rowNum, int colNum, Color colr) {
            listView1.Items[rowNum].SubItems[colNum].ForeColor = colr;
        }

        private void MenuClean_Click(object sender, EventArgs e) {
            listView1.Items.Clear();
        }
        /// <summary>
        /// Mids the specified string parameter.
        /// </summary>
        /// <param name="strParam">The string parameter.</param>
        /// <param name="startIndex">The start index.</param>
        /// <param name="length">The length.</param>
        /// <returns></returns>
        public string Mid(String strParam, int startIndex, int length) {
            return strParam.Substring(startIndex, length);
        }

        private void MenuExit_Click(object sender, EventArgs e) {
            if (fThd == null)
                Application.Exit();
            else if (fThd.IsAlive)
                fThd.Abort();

            foreach (Socket s in socketHolder.Values) {
                if (s.Connected)
                    s.Close();
            }

            foreach (Thread t in threadHolder.Values) {
                if (t.IsAlive)
                    t.Abort();
            }

            if (tcpLsn != null)
                tcpLsn.Stop();

            Application.Exit();
        }

        private void MenuStart_Click(object sender, EventArgs e) {
            if (tcpLsn == null) {
                var iPAddress = IPAddress.Parse("127.0.0.1");
                tcpLsn = new TcpListener(iPAddress, 8002);
                tcpLsn.Start();
                var tcpThd = new Thread(new ThreadStart(WaitingForClient));
                if (connectId != 0)
                    threadHolder.Add(connectId, tcpThd);
                tcpThd.Start();
                stpanel.Text = "Listen at: " + tcpLsn.LocalEndpoint.ToString();
                layer2_Stop.Checked = false;
                layer2_Start.Checked = true;
            }
        }

        private void MemuStop_Click(object sender, EventArgs e) {
            //Thread tcpThd = (Thread)threadHolder[0];
            //tcpThd.Abort() ;
            //threadHolder.Remove(0);
            stpanel.Text = "Start Server Please!";
            foreach (Socket s in socketHolder.Values) {
                if (s.Connected)
                    s.Close();
            }
            foreach (Thread t in threadHolder.Values) {
                if (t.IsAlive) {
                    t.Abort();
                    threadHolder.Remove(t);
                }
            }

            tcpLsn.Stop();
            tcpLsn = null;

            layer2_Stop.Checked = true;
            layer2_Start.Checked = false;
        }
    }
}
