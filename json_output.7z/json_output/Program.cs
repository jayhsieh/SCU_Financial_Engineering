﻿using Newtonsoft.Json;
using Npgsql;
using System;
using System.Data.SqlClient;

namespace json_output {
    class Audibot {
        static string connstr = @"Server=localhost;Database=postgres;User Id=postgres;Password=postgres;";

        /// <summary>
        /// select all fields form table form_210 no matter what there is SQL condition or not
        /// </summary>
        /// <example>
        /// @"select * from form_210 [where no=_no and iso_chapter=_iso_chapter and conten_content and score=_score]
        /// the Brackets above is optional, there is only one conjection method "and" whcih this API provided. 
        /// </example>
        /// <param name="_no">default is null string</param>
        /// <param name="_iso_chapter">default is null string</param>
        /// <param name="_content">default is null string</param>
        /// <param name="_score">default is null string</param>
        static public void select_form_210(string _no = null, string _iso_chapter = null, string _content = null, string _score = null) {
            int condition_number = 0;
            string condition_str = "";

            if (_no != null) {
                condition_number += 1;
                if (condition_number == 1)
                    condition_str = " where no=" + _no;
                else
                    condition_str += " and no=" + _no;
            }

            if (_iso_chapter != null) {
                condition_number += 1;
                if (condition_number == 1)
                    condition_str = " where iso_chapter='" + _iso_chapter + "'";
                else
                    condition_str += " and iso_chapter='" + _iso_chapter + "'";
            }

            if (_content != null) {
                condition_number += 1;
                if (condition_number == 1)
                    condition_str = " where iso_chapter='" + _content + "'";
                else
                    condition_str += " and iso_chapter='" + _content + "'";
            }

            if (_score != null) {
                condition_number += 1;
                if (condition_number == 1)
                    condition_str = " where score=" + _score;
                else
                    condition_str += " and score=" + _score;
            }

            string SQL = @"select * from form_210";
            if (condition_number != 0)
                SQL += condition_str;

            using (NpgsqlConnection conn = new NpgsqlConnection(connstr)) {
                conn.Open();

                // Define a query
                NpgsqlCommand cmd = new NpgsqlCommand(SQL, conn);

                // Execute a query
                NpgsqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read()) {
                    //建立物件，塞資料
                    RootObject_210 root = new RootObject_210 {
                        no = Convert.ToInt64(dr[0]),
                        iso_chapter = Convert.ToString(dr[1]),
                        content = Convert.ToString(dr[2]),
                        score = Convert.ToInt64(dr[3])
                    };
                    //物件序列化
                    string strJson = JsonConvert.SerializeObject(root, Formatting.Indented);
                    //輸出結果
                    Console.WriteLine(strJson);
                }
            }
        }
        /// <summary>
        /// insert a new record into the table form_210
        /// </summary>
        /// <param name="_no">primary key and not null</param>
        /// <param name="_iso_chapter">could be null</param>
        /// <param name="_content">could be null</param>
        /// <param name="_score">could be null</param>
        static public void insert_into_form_210(int _no, string _iso_chapter = null, string _content = null, int _score = 0) {
                        
            using (NpgsqlConnection conn = new NpgsqlConnection(connstr)) {
                conn.Open();
                string SQL = @"INSERT INTO form_210(no,iso_chapter,content,score) VALUES(@Parameter1, @Parameter2, @Parameter3, @Parameter4)";

                // Define a query
                NpgsqlCommand cmd = new NpgsqlCommand(SQL, conn);
                cmd.Parameters.Add(new NpgsqlParameter("@Parameter1", _no));

                if (_iso_chapter != null)
                    cmd.Parameters.Add(new NpgsqlParameter("@Parameter2", _iso_chapter));
                else
                    cmd.Parameters.Add(new NpgsqlParameter("@Parameter2", _iso_chapter)).Value = DBNull.Value;

                if (_content != null)
                    cmd.Parameters.Add(new NpgsqlParameter("@Parameter3", _content));
                else
                    cmd.Parameters.Add(new NpgsqlParameter("@Parameter3", _content)).Value = DBNull.Value;

                if (_score != 0)
                    cmd.Parameters.Add(new NpgsqlParameter("@Parameter4", _score));
                else
                    cmd.Parameters.Add(new NpgsqlParameter("@Parameter4", _score)).Value = DBNull.Value;

                // Execute non query
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
            }
        }

        static void Main(string[] args) {
            //select_form_210(null,"555",null);
            insert_into_form_210(9999);
        }
    }

    struct RootObject_210 {
        public Int64 no {
            get;
            set;
        }
        public string iso_chapter {
            get;
            set;
        }
        public string content {
            get;
            set;
        }
        public Int64 score {
            get;
            set;
        }
    }
}
