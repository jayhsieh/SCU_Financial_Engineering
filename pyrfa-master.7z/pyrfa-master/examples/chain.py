#!/usr/bin/python
#
# Decoding a legacy chain ric
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
