#!/usr/bin/python
#
# Subscribe to market price and and pause the streaming. Once paused,
# updates are conflated at ADS. To get 10-second conflated update, just
# resume and pause again every 10 seconds.
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
