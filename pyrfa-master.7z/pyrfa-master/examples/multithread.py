#!/usr/bin/python
#
# Multithread publisher and subscriber implementation example
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
