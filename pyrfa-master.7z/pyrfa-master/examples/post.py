#!/usr/bin/python
#
# OMM Posting (off-stream) leverages on consumer login channel to contribute aka. "post" data
# up to ADH/ADS cache. Posted service must be up.
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
