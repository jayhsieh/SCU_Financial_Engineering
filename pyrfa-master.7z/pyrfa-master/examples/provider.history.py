#!/usr/bin/python
#
# Non-interactive (full cached) publisher for history domain
# HISTORY provides full indexed time series
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
