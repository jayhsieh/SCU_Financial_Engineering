#!/usr/bin/python
#
# Interactive (server) publisher for market price domain
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
