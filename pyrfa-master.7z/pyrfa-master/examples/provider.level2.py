#!/usr/bin/python
#
# Non-interactive (full cached) publisher for market price domain
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
 