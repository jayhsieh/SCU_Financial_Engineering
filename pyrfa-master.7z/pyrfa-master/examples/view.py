#!/usr/bin/python
#
# Specify a set of fields in a request to subscribe only defined field.
#
print("\
Available on PyRFA Enterprise Support. Please visit http://devcartel.com/pyrfa-enterprise for more information.\
")
